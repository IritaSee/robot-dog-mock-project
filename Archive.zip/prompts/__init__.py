from .rag_earthquake_sysprompt import RAG_EARTHQUAKE_SYSPROMPT
from .react_system import REACT_SYSTEM_PROMPT

__all__ = [
    "RAG_EARTHQUAKE_SYSPROMPT",
    "REACT_SYSTEM_PROMPT",
]
